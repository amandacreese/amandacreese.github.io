window.PrimarySiteBuildAssets.insertSharedContent (
  'https://west-somerset-academies-trust.stage-primarysite.net/trust-documents/',
  '#shared-wrapper'
);
